function navigateToHomePage() {
  window.location.href = "index.html";
}

function navigateToExtraPage() {
  window.location.href = "Projects.html";
}

function notcool() {
  window.location.href = "setup.html";
}

function navigateToHomeprepage() {
  window.location.href = "setup.html";
}

function navigateToAnotherPage() {
  window.location.href = "<-- Back to Home Page";";
}


